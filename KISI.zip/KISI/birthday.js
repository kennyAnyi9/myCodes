"use strict";

let bigBtn = document.querySelector(".bigBtn");
let clickMe = document.querySelector(".clickMe");
let message = document.querySelector(".message");

clickMe.addEventListener("click", function () {
  bigBtn.classList.add("hidden");
  message.classList.remove("hidden");
});
